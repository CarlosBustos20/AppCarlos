package com.prueba.appcb;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MiPedido extends AppCompatActivity {

    EditText Nombre;
    EditText Cantidad;
    EditText Direccion;
    Spinner Comida;


    // Botones Explicitos (
    Button btnRealizarPedido;
    Button btnHistorial;
    Button btnAyuda;

    // Botones Impicitos

    Button btnUbicacion;
    Button btnWeb;
    Button btnLlamar;
    Button btnCorreo;
    Button btnCamara;

    final int PERMISO_CAMARA = 100;
    final int PERMISO_LLAMADA = 200;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_mi_pedido);

        // conexion de componentes del xml

        Nombre = findViewById(R.id.Nombre);
        Cantidad=findViewById(R.id.Cantidad);
        Direccion = findViewById(R.id.Direccion);
        Comida=findViewById(R.id.Comida);

        btnRealizarPedido= findViewById(R.id.btnRealizarPedido);
        btnHistorial=findViewById(R.id.btnHistorial);
        btnAyuda = findViewById(R.id.btnAyuda);
        btnUbicacion=findViewById(R.id.btnUbicacion);
        btnWeb = findViewById(R.id.btnWeb);
        btnLlamar=findViewById(R.id.btnLlamar);
        btnCorreo= findViewById(R.id.btnCorreo);
        btnCamara= findViewById(R.id.btnCamara);


        // Cargar Spinner de Comidas
        String[] comidas = {"Hamburguesa ", "Pizza Doble queso", "Papas Fritas"};
        Comida.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, comidas));

        // 1. Confirmar Pedido
        btnRealizarPedido.setOnClickListener(view -> {
            String nombre = Nombre.getText().toString().trim();
            String cantidad = Cantidad.getText().toString().trim();

            if (nombre.isEmpty() || cantidad.isEmpty()) {
                Toast.makeText(MiPedido.this, "Completa el nombre y la cantidad", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(MiPedido.this, PedidoConfi.class);
            intent.putExtra("CLIENTE", nombre);
            intent.putExtra("COMIDA", Comida.getSelectedItem().toString());
            intent.putExtra("CANTIDAD", cantidad);
            startActivity(intent);
        });

        // 2. Ver Historial
        btnHistorial.setOnClickListener(view -> {
            Intent intent = new Intent(MiPedido.this, Historial.class);
            startActivity(intent);
        });

        // 3. Abrir Ayuda
        btnAyuda.setOnClickListener(view -> {
            Intent intent = new Intent(MiPedido.this, Ayuda.class);
            startActivity(intent);
        });



        // INTENTS IMPLÍCITOS (5)


        // 1. Abrir Ubicación en Mapa
        btnUbicacion.setOnClickListener(view -> abrirMapa());

        // 2. Abrir Menú Web
        btnWeb.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.santotomas.cl"));
            startActivity(intent);
        });

        // 3. Llamar al Restaurante
        btnLlamar.setOnClickListener(view -> realizarLlamada());

        // 4. Contactar por Correo
        btnCorreo.setOnClickListener(view -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:contacto@restaurante.cl"));
            intent.putExtra(Intent.EXTRA_SUBJECT, "Consulta sobre Pedido");
            intent.putExtra(Intent.EXTRA_TEXT, "Hola, quisiera consultar sobre las promociones del día.");
            try {
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(MiPedido.this, "No hay aplicación de correo instalada", Toast.LENGTH_SHORT).show();
            }
        });

        // 5. Tomar Foto del Pedido
        btnCamara.setOnClickListener(view -> tomarFoto());
    }


    // Metodo Abrir Mapa
    private void abrirMapa() {
        String direccionText = Direccion.getText().toString().trim();
        String uriString = direccionText.isEmpty() ? "geo:0,0?q=Restaurante" : "geo:0,0?q=" + Uri.encode(direccionText);

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uriString));
        startActivity(intent);
    }


    //Metodo Llamada
    private void realizarLlamada() {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:6004442000"));
        startActivity(intent);
    }


    // Metodo Foto
    private void tomarFoto() {
        // Revisamos si tenemos el permiso de cámara
        if (ActivityCompat.checkSelfPermission(
                MiPedido.this,
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            // Pedimos el permiso
            ActivityCompat.requestPermissions(
                    MiPedido.this,
                    new String[]{Manifest.permission.CAMERA},
                    PERMISO_CAMARA
            );
            return;
        }

        // Abrimos la cámara del sistema
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(MiPedido.this, "No se puede abrir la cámara", Toast.LENGTH_SHORT).show();
        }
    }


    // Respuesta de los permisos

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            @NonNull String[] permissions,
            @NonNull int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Permiso de Cámara
        if (requestCode == PERMISO_CAMARA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(MiPedido.this, "Permiso de cámara aceptado", Toast.LENGTH_SHORT).show();
                tomarFoto();
            } else {
                Toast.makeText(MiPedido.this, "Permiso de cámara rechazado", Toast.LENGTH_SHORT).show();
            }
        }
    }
}




